﻿using Calculator.Operators.Abstracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    internal class ExpressionTree
    {
        public Node LastEvaluatedNode { get; private set; }

        public readonly Node Root = new Bracers();



        public abstract class Node
        {
            public ExpressionTree Host { get; set; }
            public Node Parent { get; set; }
            public int Origin { get; set; }

            public abstract double Value { get; }
            
            public abstract void AttachNode(Node node);
            public abstract void InsertOperator(Operator node);
        }



        public class Operator : Node
        {
            public Node Left { get; private set; }
            public Node Right { get; private set; }

            public Operators.Abstracts.Operator Core { get; }

            public Operator(Operators.Abstracts.Operator @operator)
            {
                Core = @operator;
            }

            public override double Value
            {
                get
                {
                    var left = Left?.Value;
                    var right = Right?.Value;
                    Host.LastEvaluatedNode = this;
                    return Core.Execute(left, right);
                }
            }

            public override void AttachNode(Node child)
            {
                AttachNodeRight(child);
            }

            public void AttachNodeRight(Node child)
            {
                if (child == null)
                    throw new ArgumentNullException();
                if (Right != null)
                    throw new InvalidOperationException();

                Right = child;
                child.Parent = this;
            }

            public void AttachNodeLeft(Node child)
            {
                if (child == null)
                    throw new ArgumentNullException();
                if (Left != null)
                    throw new InvalidOperationException();

                Left = child;
                child.Parent = this;
            }

            public override void InsertOperator(Operator node)
            {
                if (node == null)
                    throw new ArgumentNullException();

                if (node.Core.Priority > this.Core.Priority)
                {
                    if (this.Right != null)
                    {
                        node.Left = this.Right;
                        node.Left.Parent = node;
                    }
                    node.Parent = this;
                    this.Right = node;
                }
                else
                {
                    Parent.InsertOperator(node);
                }
            }

            public override string ToString()
            {
                return $"{Left} {Core} {Right}";
            }
        }



        public class Operand : Node
        {
            public Operand(double value)
            {
                Value = value;
            }

            public override double Value { get; }

            public override void AttachNode(Node child)
            {
                throw new InvalidOperationException();
            }

            public override void InsertOperator(Operator node)
            {
                throw new InvalidOperationException();
            }

            public override string ToString()
            {
                return Value.ToString();
            }
        }



        public class Bracers : Node
        {
            public bool AreClosed { get; set; }
            public Node Enclosed { get; private set; }

            public override double Value
            {
                get
                {
                    if (Enclosed == null)
                        throw new ApplicationException($"Empty bracers at position [{Origin}].");
                    return Enclosed.Value;
                }
            }

            public override void AttachNode(Node node)
            {
                if (node == null)
                    throw new ArgumentNullException();
                
                if (Enclosed == null)
                {
                    Enclosed = node;
                    node.Parent = this;
                }
                else
                    throw new ApplicationException($"Missing operator at position [{node.Origin}].");
            }

            public void DetachNode(Node node)
            {
                if (node == null)
                    throw new ArgumentNullException();

                if (Enclosed == node)
                {
                    Enclosed = null;
                    node.Parent = null;
                }
            }

            public override void InsertOperator(Operator node)
            {
                if (node == null)
                    throw new ArgumentNullException();

                if (AreClosed)
                {
                    Parent.InsertOperator(node);
                }
                else
                {
                    if (Enclosed != null)
                    {
                        var expression = Enclosed;
                        DetachNode(expression);
                        node.AttachNodeLeft(expression);
                    }
                    AttachNode(node);
                }
            }

            public override string ToString()
            {
                return $"({Enclosed})";
            }
        }
    }
}
